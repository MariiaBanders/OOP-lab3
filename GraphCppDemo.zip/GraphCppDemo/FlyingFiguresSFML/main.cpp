#include <SFML/Graphics.hpp>

#include <cmath>
#include <ctime>
#include <cstdlib>

#include <chrono>
#include <thread>

using namespace std;

class test {
public:
	test(int a) {
	}

	int f1(int b) {
		return b++;
	}

	int f1(test b) {
		return 3;
	}

	int operator /(int b) {
		return 1;
	}

	int operator /(test t) {
		return 2;
	}
};

int main()
{
	test t1(3), t2(2), t3(1);

	t3 = t1 / t2;
	t3 = t1 / 4;

	int winWidth = 500;
	int winHeight = 500;

	sf::RenderWindow window(sf::VideoMode(winWidth, winHeight), "SFML works!");
	sf::CircleShape shape(100.f);
	shape.setFillColor(sf::Color::Green);


	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
		}

		window.clear();
		window.draw(shape);
		window.display();
	}

	return 0;

}